<?php
/* Main Footer Template */
?>

</main>
<div class="sidebar-container">
    <?php if (is_active_sidebar('sidebar1')): ?>
        <div class="widget-container"> <?php dynamic_sidebar('sidebar1'); ?></div>
    <?php endif; ?>
    <?php if (is_active_sidebar('sidebar2')): ?>
        <div class="widget-container"> <?php dynamic_sidebar('sidebar2'); ?></div>
    <?php endif; ?>
</div>
<footer class="footer">
    <nav class="header-nav">
        <?php
        wp_nav_menu($arg = [
            'theme_location' => 'footer'
        ]);
        ?>
    </nav>
    <?php wp_footer(); ?>
</footer>
</div>
</body>
</html>