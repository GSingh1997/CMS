<?php get_header(); ?>

    <div class="front-page-wrapper">

        <div class="about-img-wrapper"> <?php if (has_post_thumbnail()) { ?>
                <img class="user-img" src="<?php the_post_thumbnail_url(); ?>">
            <?php } ?>
            <h2 class="about-me-h2"><span>About me</span></h2></p>
        </div>


        <?php if (have_posts()) : while (have_posts()) : the_post();
            the_content();
        endwhile; endif; ?>

    </div>

<?php get_footer(); ?>