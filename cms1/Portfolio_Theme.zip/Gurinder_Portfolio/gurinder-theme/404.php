﻿<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
*/

get_header(); ?>

    <section class="section error" id="content">
        <h1 class="error-title"><strong>404</strong></h1>
        <h2 class="error-subtitle"><strong>Oops something went wrong...</strong></h2>
        <p> Either the adress you typed is wrong or the link might be broken!</p>
        <p>If you're certain the path is correct, <a href="mailto:gurinderbelgium997@gmail.com?SUBJECT=Wordpress%20404error%20by%20user">please let me know</a></p>
    </section>

<?php get_footer(); ?>