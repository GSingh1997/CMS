<?php get_header(); ?>
<div class="projects-wrapper">

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article class="project-items">
    <h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
    </h2>
    <img class="all-imgs" src="<?php the_post_thumbnail_url(); ?>">
    <h4>Location: <?php the_field('venue_location') ?></h4>
    <h4>Date: <?php the_field('date_project') ?></h4>
    <h4>Type: <strong><?php the_field('type_project') ?></strong></h4>
    <p><?php the_field('preview_info') ?></p>
    <span>
        <a href="<?php the_permalink(); ?>">Read more</a>
    </span></article>
<?php endwhile; endif; ?></div>
<?php get_footer(); ?>