<?php

if (!function_exists('portfolio_setup')) {
    function portfolio_setup()
    {
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('custom-logo');
    }
}

remove_action('shutdown', 'wp_ob_end_flush_all', 1);

add_action('after_setup_theme', 'portfolio_setup');

function register_portfolio_menus()
{
    register_nav_menus(
        [
            'primary' => __('Primary Menu'),
            'footer' => __('Footer Social Menu')
        ]
    );
}

add_action('init', 'register_portfolio_menus');

function portfolio_scripts()
{
    wp_enqueue_style('portfolio_styles', get_stylesheet_uri());
    wp_enqueue_style('font_awesome_5_brands', 'https://use.fontawesome.com/releases/v5.5.0/css/brands.css');
    wp_enqueue_style('font_awesome_5', 'https://use.fontawesome.com/releases/v5.5.0/css/fontawesome.css');
    wp_enqueue_style('font_awesome_5_solid', 'https://use.fontawesome.com/releases/v5.5.0/css/regular.css');
}

add_action('wp_enqueue_scripts', 'portfolio_scripts');


// Our custom widgets for sidebar

function myWidgetsInit(){

    register_sidebar(array(
        'name'=>'Sidebar-area-1',
        'id'=>'sidebar1'
    ));
    register_sidebar(array(
        'name'=>'Sidebar-area-2',
        'id'=>'sidebar2'
    ));

}

add_action('widgets_init','myWidgetsInit');


// Our custom post type function
function create_posttype() {

    register_post_type( 'projects',
        // CPT Options
        array(
            'labels' => array(
                'name' => __( 'Projects' ),
                'singular_name' => __( 'Project' )
            ),
            'public' => true,
            'has_archive' => true,
            'supports' => array(
                'title',
                'editor',
                'thumbnail',
                'custom-fields',
                'excerpt'
            ),
            'rewrite' => array('slug' => 'projects'),
        )
    );
}
// Hooking up our function to theme setup
add_action( 'init', 'create_posttype' );