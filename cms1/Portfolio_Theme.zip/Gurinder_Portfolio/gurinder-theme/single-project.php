<?php get_header(); ?>


<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="single-page-wrapper">
    <h2><a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a>
    </h2>
    <img class="single-img" src="<?php the_post_thumbnail_url(); ?>">
    <h4>Location: <?php the_field('venue_location') ?></h4>
    <h4>Date: <?php the_field('date_project') ?></h4>
    <h4>Type: <strong><?php the_field('type_project') ?></strong></h4>
    <p><?php the_field('full_info') ?></p>
    </div>
<?php endwhile; endif; ?>
<?php get_footer(); ?>