
<?php   if(have_posts()){the_post();rewind_posts();}?>
<?php if('projects' == get_post_type()){?>
<?php include(TEMPLATEPATH . '/single-project.php'); ?>
<?php }
